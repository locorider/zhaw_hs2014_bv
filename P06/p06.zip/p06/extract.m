% M. Thaler, ZHAW/2012

% m:         binary image with object to be extracted
% xS, yS:    coordinates of seed point
% theObject: object to be xtracted (referenced by seed point)

function theObject = extract(m, xS, yS)
    [M N] = size(m);

    theObject = ...
end