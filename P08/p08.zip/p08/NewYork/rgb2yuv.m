function res = rgb2yuv(img)
    [M N d] = size(img);
    res = double(zeros(M,N,d));
    for x = 1:M
        for y = 1:N
            R = double(img(x,y,1)); 
            G = double(img(x,y,2)); 
            B = double(img(x,y,3));
            T = [ 0.299,  0.587, 0.114; ...
                 -0.147, -0.289, 0.436; ...
                  0.615, -0.515, -0.10];
            res(x,y,:) = T * [R,G,B]' ;
        end
    end
end