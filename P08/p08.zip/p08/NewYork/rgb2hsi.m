function res = rgb2hsi(img)
    [M N d] = size(img);
    res = double(zeros(M,N,d));
    for x = 1:M
        for y = 1:N
            R = double(img(x,y,1)); 
            G = double(img(x,y,2)); 
            B = double(img(x,y,3));
            tn = 0.5 * (2*R - G - B);
            td = sqrt((R - G)^2 + (R - B)*(G - B));
            theta = acos(tn/(td + eps));
            if B <= G
                res(x,y,1) = theta;
            else
                res(x,y,1) = 2*pi - theta;
            end
            res(x,y,2) = 1 - 3/(R+G+B)*min([R, G, B]);
            res(x,y,3) = (R+G+B)/3;
        end
    end
end